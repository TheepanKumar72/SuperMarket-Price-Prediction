import pandas as pd
import numpy as np
import hashlib
from Cryptodome import Random
from Cryptodome.Cipher import AES
from base64 import b64encode, b64decode
from http import client
from unicodedata import category, name
from xml.etree.ElementInclude import include
from django.shortcuts import render
from django.http import HttpResponse
from pymongo import MongoClient
from sklearn.tree import DecisionTreeRegressor
from sklearn import preprocessing
from sklearn.metrics import *
from sklearn.model_selection import train_test_split
from matplotlib import pyplot as plt
import urllib.parse
import warnings
warnings.filterwarnings('ignore')