from .imports import *
from .utils import *

mongodb_url = "mongodb://localhost:27017"
#mongodb_url = "mongodb+srv://thangavel:"+urllib.parse.quote_plus("raiden@1309")+"@production.pxw2b.mongodb.net/myFirstDatabase?retryWrites=true&w=majority"


# Create your views here.
def login(request):
    return render(request,'login.html')

def product_list(request):
    user = request.POST['u_name']
    pwd = request.POST['pwd']
    
    v = validate_user(user,pwd,mongodb_url)
    
    client  = MongoClient(mongodb_url)
    temp = pd.DataFrame(client['secure_data']['products'].find({}))
    if len(temp) == 0 :
        data = client['supermarket']['login_results'].find({},{'_id':0})
        df = pd.DataFrame(data)
        en_df = encrypt_db(df)
        client['secure_data']['products'].insert_many(en_df.to_dict('records'))

    if v == 1:
        return render(request,'product_list.html',{'name':'Sir'})
    else:
        return(HttpResponse('Invalid user name or password'))

def result(request):
    category = request.GET['d_category']
    query = {
        'category':category
    }    

    client = MongoClient(mongodb_url)
    data = client['supermarket']['login_results'].find(query,{'_id':0})
    df = pd.DataFrame(data)
    html = df.to_html()  
    # write html to file
    text_file = open("login/templates/result.html", "w")
    text_file.write(html)
    text_file.close()

    #obj = model_trainer(df)
    return render(request,"result.html")

def trainer(request):
    client = MongoClient(mongodb_url)
    category = request.GET['t_category']
    
    if category == 'All':
        query = {}
    else:
        query = {
            'category':category
        }    
    data = client['supermarket']['login_results'].find(query,{'_id':0})
    df = pd.DataFrame(data)
    obj = model_trainer(df)
    prediction = obj.encoder()
    return render(request,"prediction.html",prediction)
