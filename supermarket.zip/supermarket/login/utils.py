from .imports import *


class AESCipher(object):
    def __init__(self, key):
        self.block_size = AES.block_size
        self.key = hashlib.sha256(key.encode()).digest()
    
    def encrypt(self, plain_text):
        plain_text = self.__pad(plain_text)
        iv = Random.new().read(self.block_size)
        cipher = AES.new(self.key, AES.MODE_CBC, iv)
        encrypted_text = cipher.encrypt(plain_text.encode())
        return b64encode(iv + encrypted_text).decode("utf-8")

    def decrypt(self, encrypted_text):
        encrypted_text = b64decode(encrypted_text)
        iv = encrypted_text[:self.block_size]
        cipher = AES.new(self.key, AES.MODE_CBC, iv)
        plain_text = cipher.decrypt(encrypted_text[self.block_size:]).decode("utf-8")
        return self.__unpad(plain_text)

    def __pad(self, plain_text):
        number_of_bytes_to_pad = self.block_size - len(plain_text) % self.block_size
        ascii_string = chr(number_of_bytes_to_pad)
        padding_str = number_of_bytes_to_pad * ascii_string
        padded_plain_text = plain_text + padding_str
        return padded_plain_text

    @staticmethod
    def __unpad(plain_text):
        last_character = plain_text[len(plain_text) - 1:]
        return plain_text[:-ord(last_character)]

def encrypt_db(df):
    obj = AESCipher('prime')
    for i in df.iloc[:,2:4]:
        for j in range(len(df[i])):
            df[i][j] = obj.encrypt(df[i][j])
    #print(df.head())
    return df

def validate_user(user,pwd,mongodb_url):
    client = MongoClient(mongodb_url)
    query = {
        "user":user,
        "pass":pwd
    }
    data  = list(client['main_accounts']['en_users'].find({},{'_id':0}))
    en_user = []
    en_pwd = []
    en_user_l = 0
    en_pwd_l = 0
    obj = AESCipher('login')
    for i in data:
        en_user.append(obj.decrypt(i['user']))
        en_pwd.append(obj.decrypt(i['pass']))

    for i in en_user:
        if i == user:
            en_user_l = 1
            break
    
    for i in en_pwd:
        if i == pwd:
            en_pwd_l = 1
            break

    if en_user_l == 1 and en_pwd_l == 1:
        return 1
    else:
        return 0

class model_trainer:
    def __init__(self,df):
        self.df = df
        
    def encoder(self):
        le = preprocessing.LabelEncoder()
        self.df['category'] = le.fit_transform(self.df['category'])
        self.df['item'] = le.fit_transform(self.df['item'])
        self.df['variety']=le.fit_transform(self.df['variety'])
        return self.splitter()
        
    
    def splitter(self):
        x_features=['category','item','variety']
        y_features=['price']
        X=self.df[x_features]
        y=self.df[y_features]
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
        return self.trainer(X_train, X_test, y_train, y_test,y)
    
    def trainer(self,X_train,X_test,y_train,y_test,y):
        res = dict()
        dtree = DecisionTreeRegressor(max_depth=10)
        dtree.fit(X_train, y_train)

        print('Model Training complete')
        print(X_train.shape, y_train.shape)
        print(X_test.shape, y_test.shape)
        
        predictions = dtree.predict(X_test)
        y_score = dtree.score(X_test,y_test)
        mse = mean_squared_error(y_test,predictions)
        rmse = np.sqrt(mse)
        mae = mean_absolute_error(y_test,predictions)        
        print('Predicted Output Accuracy: ', y_score)

        res['y_score'] = round(y_score,3)
        res['mse'] = round(mse,3)
        res['rmse'] = round(rmse,3)
        res['mae'] = round(mae,3)

        self.plot_results(y_test,predictions)

        return res
    
    def plot_results(self,y_actual,y_pred):

        data = {
        'actual':np.concatenate(np.array(y_actual).tolist()).flat,
        'predicted':y_pred.tolist()
        }

        plt.plot(data['actual'][:50],label='actual')
        plt.plot(data['predicted'][:50],label='predicted')
        plt.legend()
        plt.title('Actual vs Prediction')
        plt.ylabel('price')
        plt.yticks([])
        plt.savefig('login/static/results/result.jpg')
        plt.close()