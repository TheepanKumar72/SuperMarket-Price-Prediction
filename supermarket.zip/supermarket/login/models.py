from django.db import models
from django.utils.translation import gettext as _

# Create your models here.

class results(models.Model):
    id = models.CharField(_("id"),max_length=255,primary_key=True)
    category = models.CharField(_("category"),max_length=255)
    item = models.CharField(_("items"),max_length=255)
    variety = models.CharField(_("variety"),max_length=255)
    date = models.CharField(_("date"),max_length=255)
    price = models.FloatField(_("price"),max_length=255)
    unit = models.CharField(_("unit"),max_length=255)