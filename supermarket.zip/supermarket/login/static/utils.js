function success()
{
    alert('login success');
}

function fail()
{
    alert('Invalid user or password');
}